/**
 * 
 */
/**
 * @author pc
 *
 */
module HelloWorldOOPFikt {
}